    <?php
	include_once 'include/connection.php';
?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <title>Mapesi</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/pricing/">

    <!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- Custom styles for this template -->
    <link href="css/Query.css" rel="stylesheet">
  </head>
  <body>
  <!-- Header -->
    <?php include'Query/HeaderQuery.php'; ?>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">CONTABILITA' E GESTIONE</h1>
  <p class="lead">Tabella per visualizzare velocemente costi e guadagni della catena di ristoranti.</p>
</div>

<div class="container">
	
	<?php include 'QueryBoxes.php';?>
	
  <!-- Second box -->
  <div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">Personale</h4>
      </div>
      <div class="card-body" >


      <a href = "./Filiali/filiale74014.php" class ="fontlove"> Informazione su personale</a><br>


      <a href = "AggiungerePersonale.php"class ="fontlove"><button type="button" class="btn btn-lg btn-block btn-outline-primary">Inserire una Persona</button></a>
        
      </div>

      <!-- third box -->
    </div><div class="card mb-4 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">Altre operazioni</h4>
      </div>
      <div class="card-body" >



      <a href = "magazzino.php"class ="fontlove"> <button type="button" class="btn btn-lg btn-block btn-outline-primary">Gestire magazzino e ordini</button></a>

      </div>
    </div>
	

	

</div>
</body>
</html>
