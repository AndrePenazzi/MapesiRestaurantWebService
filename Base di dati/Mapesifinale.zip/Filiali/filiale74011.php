<?php
	include_once '../include/connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<meta charset="UTF-8">
	<title>Personale Filiale</title>
</head>
<body>
	<div class="container">
		<div class="row">
		<?php
		if(isset($_POST['search'])){
			$searchKey = $_POST['search'];
			$sql = "select * from personale as p
					INNER JOIN lavora as l
					ON p.CF = l.CF
			where CodiceFiliale = 74011 and Nome LIKE '%$searchKey%' ";
		}else{
			$sql = "select * from personale as p
					INNER JOIN lavora as l
					ON p.CF = l.CF
					where CodiceFiliale = 74011";
			$searchKey = "";
		}
		
		$result = mysqli_query($conn, $sql);
		?>
			<div class="col-md-8 col-md-offset-2" style="margin-top: 5%;">
				<div class="row">
				<form action="" method="POST"> 
					<div class="col-md-6">
						<input type="text" name="search" class='form-control' placeholder="Search By Name" value="<?php echo $searchKey; ?>" > 
					</div>
					<div class="col-md-6 text-left">
						<button class="btn">Search</button>
					</div>
				</form>

				<br>
				<br>
				</div>

				<table class="table table-bordered">
					<tr>
						<th>Nome</th>
						<th>Cognome</th>
						<th>Ruolo</th>
						<th>CodiceFiliale</th>
						<th>CodiceDipendente</th>

					</tr>
					<?php while($row = mysqli_fetch_object($result)) { ?>
					<tr>
						<td> <?php echo $row->Nome ?> </td>
						<td> <?php echo $row->Cognome ?> </td>
						<td> <?php echo $row->Ruolo ?> </td>
						<td> <?php echo $row->CodiceFiliale ?> </td>
						<td> <?php echo $row->CodiceDipendente ?> </td>

					</tr>
					<?php } ?>
				</table>

                <div class="aggiungere">
                    <form action="" method="POST">
                        <input type="text" name="CodiceDipendente" placeholder="CodiceDipendente">
                        <button type="submit" name = "delete" class="btn btn-primary">DELETE</button>
                        <button type="submit" name = "back" class="btn btn-outline-success"><a href="../Queries.php">Staff</a></button>
                </div>
                </form>
                <?php
                       $CodiceDipendente = $_POST['CodiceDipendente'];

                       $dlt ="delete from personale where CodiceDipendente = '$CodiceDipendente'";
                       $dltquery = mysqli_query($conn, $dlt);

                       if ($dltquery){
                           echo "<font color='green' style='font-size: large'>record deleted";

                       }else{
                           echo "<font color='red'>sorry, process failed!!";
                       }

                 ?>
							
			</div>
		</div>
	</div>
</body>
</html>