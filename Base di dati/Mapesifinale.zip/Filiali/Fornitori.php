<?php
include_once '../include/connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="../MenuPage/css1/bootstrap.min.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/font-awesome.min.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/flaticon.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/owl.carousel.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/style.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/animate.css"/>


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <meta charset="UTF-8">
    <title>Fornitori</title>
</head>


<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal">Mapesi Group of Restaurants</h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="../magazzino.php"><button type="submit" name = "Magazzino" class="btn btn-outline-success">Magazzino</button></a>
        <a class="p-2 text-dark" href="../index.php"><button type="submit" name = "Home" class="btn btn-outline-success">Home</button></a>
    </nav>
</div>

<body>
<div class="container">
    <div class="row">
        <?php
        if(isset($_POST['search'])){
            $searchKey = $_POST['search'];
            $sql = "SELECT * FROM fornitori AS f
			WHERE Nome LIKE '%$searchKey%' OR Tipologia LIKE '%$searchKey%'";
        }else{
            $sql = "select * from fornitori as f";
            $searchKey = "";
        }

        $result = mysqli_query($conn, $sql);
        ?>
        <div class="col-md-8 col-md-offset-2" style="margin-top: 5%;">
            <div class="row">
                <form action="" method="POST">
                    <div class="col-md-6">
                        <input type="text" name="search" class='form-control' placeholder="Search By Name" value="<?php echo $searchKey; ?>" >
                    </div>
                    <div class="col-md-6 text-left">
                        <button class="btn">Search</button>
                    </div>
                </form>

                <br>
                <br>
            </div>
            <table class="table table-bordered">
                <tr>
                    <th>PIVA</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipologia</th>
                    <th>Città</th>
                </tr>
                <?php while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                                    <td>".$row['PIVA']."</td>
                                    <td>".$row['Nome']."</td>
                                    <td>".$row['Email']."</td>
                                    <td>".$row['Tipologia']."</td>
                                    <td>".$row['Città']."</td>
                            </tr>";
                } ?>
            </table>

            <a href="../Queries.php"><button type="submit" name = "back" class="btn btn-success">Indietro</button></a>
            <a href="../AggiungereFornitori.php"><button type="submit" name = "new" class="btn btn-secondary">Aggiungi</button></a>

        </div>
    </div>
</div>
</body>
</html>