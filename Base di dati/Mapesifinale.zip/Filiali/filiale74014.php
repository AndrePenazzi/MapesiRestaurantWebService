<?php
	include_once '../include/connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Pulse Restaurant HTML Template">
    <meta name="keywords" content="pulse, restaurant, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../MenuPage/css1/bootstrap.min.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/font-awesome.min.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/flaticon.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/owl.carousel.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/style.css"/>
    <link rel="stylesheet" href="../MenuPage/css1/animate.css"/>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<meta charset="UTF-8">
	<title>Personale Filiale</title>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal">Mapesi Group of Restaurants</h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a href="../Queries.php"><button type="submit" name = "back" class="btn btn-outline-success">Staff</button></a>
        <a class="p-2 text-dark" href="Fornitori.php"><button type="submit" name = "fornitori" class="btn btn-outline-success">Fornitori</button></a>
        <a class="p-2 text-dark" href="../index.php"><button type="submit" name = "Home" class="btn btn-outline-success">Home</button></a>
    </nav>
</div>

<body>
	<div class="contain">
		<div class="row">
		<?php
		if(isset($_POST['search'])){
			$searchKey = $_POST['search'];
			$sql = "SELECT * FROM personale AS p
					INNER JOIN lavora AS l
					ON p.CF = l.CF
			WHERE Nome LIKE '%$searchKey%' OR  CodiceFiliale LIKE '%$searchKey%' OR CodiceDipendente LIKE '%$searchKey%' OR  Ruolo LIKE '%$searchKey%' OR  GiornoRiposo LIKE '%$searchKey%'";
		}else{
			$sql = "select * from personale as p
					INNER JOIN lavora as l
					ON p.CF = l.CF
					/*where CodiceFiliale = 74014*/";
			$searchKey = "";
		}
		
		$result = mysqli_query($conn, $sql);
		?>


			<div class="col-md-8 col-md-offset-2" style="margin-top: 5%;">
				<div class="row">
				<form action="" method="POST"> 
					<div class="col-md-6">
						<input type="text" name="search" class='form-control' placeholder="cerca..." value="<?php echo $searchKey; ?>" >
					</div>
					<div class="col-md-6 text-left">
						<button class="btn">Search</button>
					</div>
				</form>

				<br>
				<br>
				</div>
				<table class="table table-bordered">
					<tr>
						<th>Nome</th>
						<th>Cognome</th>
						<th>Ruolo</th>
						<th>CodiceFiliale</th>
						<th>CodiceDipendente</th>
                        <th>GiornoRiposo</th>
                        <th colspan="2" >Operazioni</th>



					</tr>
					<?php while($row = mysqli_fetch_assoc($result)) {
					        echo "<tr>
                                    <td>".$row['Nome']."</td>
                                    <td>".$row['Cognome']."</td>
                                    <td>".$row['Ruolo']."</td>
                                    <td>".$row['CodiceFiliale']."</td>
                                    <td>".$row['CodiceDipendente']."</td>
                                    <td>".$row['GiornoRiposo']."</td>
                                    
                                    <td><a href='../include/update.php? cf=$row[CF]& name=$row[Nome]& cog=$row[Cognome]
                                    & r=$row[Ruolo]& cfi=$row[CodiceFiliale]& cd=$row[CodiceDipendente]& c=$row[Citta]& gr=$row[GiornoRiposo]& p=$row[PagaOraria]& tel=$row[Telefono]& da=$row[DataAssunzione]& ol=$row[OreLavorate]'><button class='btn-warning btn'> Aggiorna</button></a></td>
                                    
                                    <td><a href='../include/delete.php? id=$row[CF]' class='text-white' onclick='checkdelete()'><button class='btn-danger btn'> Elimina</button></a></td>
                            </tr>";
					 } ?>
				</table>

                <script>
                    function checkdelete()
                    {
                        return confirm('Sei sicuri di eliminare il dato!!');
                    }
                </script>

			</div>
		</div>
	</div>
</body>
</html>