<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
.aggiungere{
width:600px;
margin:50px;
font: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
border-radius:10px;
border:2px solid #ccc;
padding:10px 40px 25px;
margin-top:70px; 	
}
input[type=text]{
width:50%;
padding:10px;
margin-top:8px;
border:1px solid #ccc;
padding-left: 5px;
font-size:16px;
font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
}

button{
margin-top:8px;
}
</style>
</head>