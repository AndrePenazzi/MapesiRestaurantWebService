

<link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/pricing/">
<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="css/Query.css" rel="stylesheet">

<?php

include 'include/connection.php';
include 'css/AggiungereCSS.php'
?>


<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal">Mapesi Group of Restaurants</h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php">Home</a>
    </nav>
</div>

<div class="aggiungere">
    <form action="Aggiungi%20Fornitori.php" method="POST">
        <div class="form-row">

            <h1>Inserire informazione richiesta</h1>
            <!--<input type="text" name="idmenu" placeholder="idmenu">
            <input type="text" name="nomemenu" placeholder="nomemenu">
            <input type="text" name="prezzomenu" placeholder="prezzomenu">-->


            <input type="text" name="PIVA" placeholder="Partita iva">

            <input type="text" name="Nome" placeholder="Nome">

            <input type="text" name="Email" placeholder="E-mail">

            <input type="text" name="Tipologia" placeholder="Tipologia">

            <input type="text" name="Città" placeholder="Città">

            <button type="submit" name = "submit" class="btn btn-primary">Aggiungere</button>
        </div>
    </form>


    <button type="submit" name = "submit" class="btn btn-dark"><a href="./Filiali/Fornitori.php" >Torna alla pagina fornitori</a></button>








