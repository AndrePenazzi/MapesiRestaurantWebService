<?php

    include 'include/connection.php';
    include 'css/AggiungereCSS.php'
?>

		
		<div class="aggiungere">
		<form action="" method="POST">
		  <div class="form-row">

              <h1>Inserire informazione richiesta</h1>
              <!--<input type="text" name="idmenu" placeholder="idmenu">
              <input type="text" name="nomemenu" placeholder="nomemenu">
              <input type="text" name="prezzomenu" placeholder="prezzomenu">-->


			  <input type="text" name="cf" placeholder="CF">
			
			  <input type="text" name="CodiceDipendente" placeholder="CodiceDipendente">
			
			  <input type="text" name="Nome" placeholder="Nome">
			
			  <input type="text" name="Cognome" placeholder="Cognome">
			
			  <input type="text" name="Ruolo" placeholder="Ruolo">
			
			  <input type="text" name="Città" placeholder="Città">
			
			  <input type="text" name="GiornoRiposo" placeholder="GiornoRiposo">
			
			  <input type="text" name="PagaOraria" placeholder="PagaOraria">
			
			  <input type="text" name="Telefono" placeholder="Telefono">
			
              <input type="text" name="CodiceFiliale" placeholder="CodiceFiliale">
			
			  <input type="text" name="DataAssunzione" placeholder="DataAssunzione">
			
			  <input type="text" name="OreLavorate" placeholder="OreLavorate">
			
			
			
		  <button type="submit" name = "submit" class="btn btn-primary">Aggiungere</button>
		  </div>
		</form>
            <?php

            $cf = $_POST['cf'];
            $CodiceDipendente = $_POST['CodiceDipendente'];
            $Nome = $_POST['Nome'];
            $Cognome = $_POST['Cognome'];
            $Ruolo = $_POST['Ruolo'];
            $Città = $_POST['Città'];
            $GiornoRiposo = $_POST['GiornoRiposo'];
            $PagaOraria = $_POST['PagaOraria'];
            $Telefono = $_POST['Telefono'];
            $CodiceFiliale = $_POST['CodiceFiliale'];
            $DataAssunzione = $_POST['DataAssunzione'];
            $OreLavorate = $_POST['OreLavorate'];

            $sql = "insert into personale values ('$cf', '$CodiceDipendente', '$Nome', '$Cognome', '$Ruolo', '$Città', '$GiornoRiposo', '$PagaOraria', '$Telefono')";
            $query = mysqli_query($conn, $sql);

            if($query){
                $sql2 = "insert into lavora values ('$CodiceDipendente', '$cf', '$CodiceFiliale', '$DataAssunzione', '$OreLavorate')";
                mysqli_query($conn, $sql2);

            }

            header("location:/Mapesi/Filiali/filiale74014.php");
            ?>

            <a href="Queries.php" ><button type="submit" name = "submit" class="btn btn-dark">Torna alla pagina personale</button></a>






	
	
	