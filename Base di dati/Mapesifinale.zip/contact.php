<?php
include_once 'include/connection.php';

        $sql = "SELECT *from ristoranti;";
        $result = mysqli_query($conn, $sql);
        $resultCheck = mysqli_num_rows($result);
        $data = array();

        if($resultCheck > 0){
            while($row = mysqli_fetch_assoc($result)){
                $data[]= $row['Città'];
                $data1[]= $row['Indirizzo'];
                $data2[]= $row['Telefono'];
                $data3[]= $row['e-mail'];

            }
        }

?>


<head>

    <title>Mapesi - Restaurant </title>
    <meta charset="UTF-8">
    <meta name="description" content="Pulse Restaurant HTML Template">
    <meta name="keywords" content="pulse, restaurant, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link href="MenuPage/img/favicon.ico" rel="shortcut icon"/>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="MenuPage/css1/bootstrap.min.css"/>
    <link rel="stylesheet" href="MenuPage/css1/font-awesome.min.css"/>
    <link rel="stylesheet" href="MenuPage/css1/flaticon.css"/>
    <link rel="stylesheet" href="MenuPage/css1/owl.carousel.css"/>
    <link rel="stylesheet" href="MenuPage/css1/style.css"/>
    <link rel="stylesheet" href="MenuPage/css1/animate.css"/>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal">Mapesi Group of Restaurants</h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index.php"><button type="submit" name = "Home" class="btn btn-outline-success">Home</button></a>
    </nav>
</div>


<section class="ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h1><?php print_r($data[0])?></h1>
                <div class="wrapper px-md-4">
                    <div class="row mb-5">
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p><span>Address:</span> <?php print_r($data1[0])?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p><span>Phone:</span> <a href="tel://1234567920"><?php print_r($data2[0])?></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p><span>Email:</span> <a href="mailto:info@yoursite.com"><?php print_r($data3[0])?></a></p>
                                </div>
                            </div>
                        </div>

                    </div>
                    </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h1><?php print_r($data[1])?></h1>
                <div class="wrapper px-md-4">
                    <div class="row mb-5">
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p><span>Address:</span> <?php print_r($data1[1])?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p><span>Phone:</span> <a href="tel://1234567920"><?php print_r($data2[1])?></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p><span>Email:</span> <a href="mailto:info@yoursite.com"><?php print_r($data3[1])?></a></p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h1><?php print_r($data[2])?></h1>
                <div class="wrapper px-md-4">
                    <div class="row mb-5">
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p><span>Address:</span> <?php print_r($data1[2])?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p><span>Phone:</span> <a href="tel://1234567920"><?php print_r($data2[2])?></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p><span>Email:</span> <a href="mailto:info@yoursite.com"><?php print_r($data3[2])?></a></p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h1><?php print_r($data[3])?></h1>
                <div class="wrapper px-md-4">
                    <div class="row mb-5">
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p><span>Address:</span> <?php print_r($data1[3])?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p><span>Phone:</span> <a href="tel://1234567920"><?php print_r($data2[3])?></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p><span>Email:</span> <a href="mailto:info@yoursite.com"><?php print_r($data3[3])?></a></p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

