<?php
include_once 'include/connection.php';
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>Mapesi - Restaurant </title>
    <meta charset="UTF-8">
    <meta name="description" content="Pulse Restaurant HTML Template">
    <meta name="keywords" content="pulse, restaurant, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link href="MenuPage/img/favicon.ico" rel="shortcut icon"/>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="MenuPage/css1/bootstrap.min.css"/>
    <link rel="stylesheet" href="MenuPage/css1/font-awesome.min.css"/>
    <link rel="stylesheet" href="MenuPage/css1/flaticon.css"/>
    <link rel="stylesheet" href="MenuPage/css1/owl.carousel.css"/>
    <link rel="stylesheet" href="MenuPage/css1/style.css"/>
    <link rel="stylesheet" href="MenuPage/css1/animate.css"/>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<!-- Page Preloder -->
<div id="preloder">
    <div class="loader"></div>
</div>

<!-- Header section -->
<header class="header-section">
    <div class="header-warp">
        <div class="site-logo">
            <h2>MAPESI<span>.</span></h2>
        </div>
        <!-- responsive -->
        <div class="nav-switch">
            <i class="fa fa-bars"></i>
        </div>
        <!-- menu -->
        <<ul class="main-menu">
            <li><a href="index.php" >Home</a></li>
            <li><a href="MenuPage.php" class="active">Menu</a></li>
            <li><a href="contact.php">Contatti</a></li>
            <li><a href="Login.php">Personale</a></li>
        </ul>
        <div class="site-logo">
            <H2><span>Group of Restaurants</span></H2>
        </div>
    </div>
</header>
<!-- Header section end -->


<!-- Page info section -->
<section class="page-top-info set-bg" data-setbg="MenuPage/img/page-top-bg/2.jpg">
    <div class="ptf-center">
        <div class="container">
            <h2>Il menu<span>.</span></h2>
        </div>
    </div>
</section>
<!-- Page info section end -->


<!-- Menu section -->
<section class="mp-menu-section spad">
    <div class="container">
            <div class="section-title">
                <i class="flaticon-022-tray"></i>
                <h2>Il nostro Menu</h2>
            </div>
        <ul class="mp-menu-tab-nav nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1"
                   aria-selected="false">
                    <i class="flaticon-005-coffee-1"></i>
                    <div class="mpm-text">
                        <h5>Antipasto</h5>

                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2"
                   aria-selected="false">
                    <i class="flaticon-013-salad"></i>
                    <div class="mpm-text">
                        <h5>Primo</h5>

                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3"
                   aria-selected="false">
                    <i class="flaticon-008-soup"></i>
                    <div class="mpm-text">
                        <h5>Secondo</h5>

                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-4" role="tab" aria-controls="tab-4"
                   aria-selected="false">
                    <i class="flaticon-018-lobster"></i>
                    <div class="mpm-text">
                        <h5>Dolce</h5>

                    </div>
                </a>
            </li>
        </ul>

        <!--Query for Ingredienti delle portate-->

        <?php
        //Query ingredienti antipasti
        $ingredient = "SELECT * FROM `portata` as p join ingredientiinportata as i on p.NomePortata = i.NomePortata";
        $queryIng = mysqli_query($conn, $ingredient);

        while ($rowIng = mysqli_fetch_assoc($queryIng)){
            if ($rowIng['TipoPortata'] == "Antipasto"){
                if ($rowIng['IDMenu'] == 2) {
                    $antipasto2[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 3) {
                    $antipasto3[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 4) {
                    $antipasto4[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 5) {
                    $antipasto5[] =  $rowIng['NomeIngrediente'];
                }
            }
        }

        //Query ingredienti Primi
        $ingredient = "SELECT * FROM `portata` as p join ingredientiinportata as i on p.NomePortata = i.NomePortata";
        $queryIng = mysqli_query($conn, $ingredient);

        while ($rowIng = mysqli_fetch_assoc($queryIng)){
            if ($rowIng['TipoPortata'] == "Primo"){
                if ($rowIng['IDMenu'] == 2) {
                    $primo2[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 3) {
                    $primo3[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 4) {
                    $primo4[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 5) {
                    $primo5[] =  $rowIng['NomeIngrediente'];
                }
            }
        }

        //Query ingredienti secondi
        $ingredient = "SELECT * FROM `portata` as p join ingredientiinportata as i on p.NomePortata = i.NomePortata";
        $queryIng = mysqli_query($conn, $ingredient);

        while ($rowIng = mysqli_fetch_assoc($queryIng)){
            if ($rowIng['TipoPortata'] == "Secondo"){
                if ($rowIng['IDMenu'] == 2) {
                    $secondo2[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 3) {
                    $secondo3[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 4) {
                    $secondo4[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 5) {
                    $secondo5[] =  $rowIng['NomeIngrediente'];
                }
            }
        }

        //Query ingredienti dolci
        $ingredient = "SELECT * FROM `portata` as p join ingredientiinportata as i on p.NomePortata = i.NomePortata";
        $queryIng = mysqli_query($conn, $ingredient);

        while ($rowIng = mysqli_fetch_assoc($queryIng)){
            if ($rowIng['TipoPortata'] == "Dolce"){
                if ($rowIng['IDMenu'] == 2) {
                    $dolce2[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 3) {
                    $dolce3[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 4) {
                    $dolce4[] =  $rowIng['NomeIngrediente'];
                }
                if ($rowIng['IDMenu'] == 5) {
                    $dolce5[] =  $rowIng['NomeIngrediente'];
                }
            }
        }

        ?>


        <!--Query for menuname and Piatti-->

        <?php
        //Query for menuname and antipasti-->
        $m = "SELECT * FROM `portata` as p join menu as m on p.idmenu = m.IDMenu where TipoPortata= 'Antipasto'";
        $queryM = mysqli_query($conn, $m);

        while ($rowm = mysqli_fetch_assoc($queryM)) {
            $menu1[] = $rowm['NomeMenù'];
            if ($rowm['IDMenu'] == 2) {
                $portata1[] = $rowm['NomePortata'];
                $prezzo1[] = $rowm['Prezzo'];
            }
            if ($rowm['IDMenu'] == 3) {
                $portata2[] = $rowm['NomePortata'];
                $prezzo2[] = $rowm['Prezzo'];
            }
            if ($rowm['IDMenu'] == 4) {
                $portata3[] = $rowm['NomePortata'];
                $prezzo3[] = $rowm['Prezzo'];
            }
            if ($rowm['IDMenu'] == 5) {
                $portata4[] = $rowm['NomePortata'];
                $prezzo4[] = $rowm['Prezzo'];
            }

        }


        //<!--Query for Primi-->

        $me = "SELECT * FROM `portata` as p join menu as m on p.idmenu = m.IDMenu where TipoPortata= 'Primo'";
        $queryMe = mysqli_query($conn, $me);

        while ($rowme = mysqli_fetch_assoc($queryMe)) {
            if ($rowme['IDMenu'] == 2) {
                $portatap1[] = $rowme['NomePortata'];
                $prezzop1[] = $rowme['Prezzo'];
            }
            if ($rowme['IDMenu'] == 3) {
                $portatap2[] = $rowme['NomePortata'];
                $prezzop2[] = $rowme['Prezzo'];
            }
            if ($rowme['IDMenu'] == 4) {
                $portatap3[] = $rowme['NomePortata'];
                $prezzop3[] = $rowme['Prezzo'];
            }
            if ($rowme['IDMenu'] == 5) {
                $portatap4[] = $rowme['NomePortata'];
                $prezzop4[] = $rowme['Prezzo'];
            }

        }


        //<!--Query for Secondi-->

        $men = "SELECT * FROM `portata` as p join menu as m on p.idmenu = m.IDMenu where TipoPortata= 'Secondo'";
        $queryMen = mysqli_query($conn, $men);

        while ($rowmen = mysqli_fetch_assoc($queryMen)) {
            if ($rowmen['IDMenu'] == 2) {
                $portatas1[] = $rowmen['NomePortata'];
                $prezzos1[] = $rowmen['Prezzo'];
            }
            if ($rowmen['IDMenu'] == 3) {
                $portatas2[] = $rowmen['NomePortata'];
                $prezzos2[] = $rowmen['Prezzo'];
            }
            if ($rowmen['IDMenu'] == 4) {
                $portatas3[] = $rowmen['NomePortata'];
                $prezzos3[] = $rowmen['Prezzo'];
            }
            if ($rowmen['IDMenu'] == 5) {
                $portatas4[] = $rowmen['NomePortata'];
                $prezzos4[] = $rowmen['Prezzo'];
            }

        }


        //<!--Query for Dolci-->

        $menu = "SELECT * FROM `portata` as p join menu as m on p.idmenu = m.IDMenu where TipoPortata= 'Dolce'";
        $queryMenu = mysqli_query($conn, $menu);

        while ($rowmenu = mysqli_fetch_assoc($queryMenu)) {
            if ($rowmenu['IDMenu'] == 2) {
                $portatad1[] = $rowmenu['NomePortata'];
                $prezzod1[] = $rowmenu['Prezzo'];
            }
            if ($rowmenu['IDMenu'] == 3) {
                $portatad2[] = $rowmenu['NomePortata'];
                $prezzod2[] = $rowmenu['Prezzo'];
            }
            if ($rowmenu['IDMenu'] == 4) {
                $portatad3[] = $rowmenu['NomePortata'];
                $prezzod3[] = $rowmenu['Prezzo'];
            }
            if ($rowmenu['IDMenu'] == 5) {
                $portatad4[] = $rowmenu['NomePortata'];
                $prezzod4[] = $rowmenu['Prezzo'];
            }

        }

        //<!--Query per Piatto della settimana-->

        $piùVenduto = "select s.NomeMenù, s.PrezzoMenu, MAX(s.total) as maximum 
                        from(SELECT Menu, NomeMenù, PrezzoMenu, sum(QuantitàMenu) total 
                                FROM `ordine` as o join menu as m on o.Menu = m.IDMenu GROUP BY Menu) as s 
                       GROUP by s.NomeMenù, s.PrezzoMenu
                       ORDER by maximum DESC LIMIT 1";
        $queryMenu =$conn ->query($piùVenduto);

        if ($rowvenduto = mysqli_fetch_assoc($queryMenu)){
            $piuVenduto = $rowvenduto;
        }
        ?>


        <div class="tab-content menu-tab-content" >

            <!-- single tab content -->
            <!--Tab Antipasti-->
            <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
                <div class="row menu-dark">

                    <!--First menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php  print_r($menu1[0]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portata1[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($antipasto2 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                 <div class="menu-price">€<?php echo $prezzo1[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Second menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[1]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portata2[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($antipasto3 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzo2[0] ?></div>
                            </div>

                        </div>

                    </div>

                    <!--Third menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[2]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portata3[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($antipasto4 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzo3[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Fourth menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[3]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portata4[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($antipasto5 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzo4[0] ?></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!-- single tab content -->
            <!--Tab Primi-->
            <div class="tab-pane fade " id="tab-2" role="tabpanel" aria-labelledby="tab-2">
                <div class="row menu-dark">

                    <!--First menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[0]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatap1[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($primo2 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzop1[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Second menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[1]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatap2[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($primo3 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzop2[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Third menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[2]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatap3[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($primo4 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzop3[0] ?></div>
                            </div>
                        </div>

                    </div>

                    <!--Fourth menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[3]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatap4[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($primo5 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzop4[0] ?></div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>


            <!-- single tab content -->
            <!--Tab Secondi-->
            <div class="tab-pane fade " id="tab-3" role="tabpanel" aria-labelledby="tab-3">
                <div class="row menu-dark">

                    <!--First menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[0]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatas1[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($secondo2 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzos1[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Second menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[1]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatas2[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($secondo3 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzos2[0] ?></div>
                            </div>
                        </div>

                    </div>

                    <!--Third menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[2]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatas3[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($secondo4 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzos3[0] ?></div>
                            </div>
                        </div>

                    </div>

                    <!--Fourth menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[3]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatas4[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($secondo5 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzos4[0] ?></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <!-- single tab content -->
            <!--Tab Dolci-->
            <div class="tab-pane fade " id="tab-4" role="tabpanel" aria-labelledby="tab-4">
                <div class="row menu-dark">

                    <!--First menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[0]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatad1[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($dolce2 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzod1[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Second menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[1]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatad2[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($dolce3 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzod2[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Third menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[2]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatad3[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($dolce4 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzod3[0] ?></div>
                            </div>
                        </div>
                    </div>

                    <!--Fourth menu-->
                    <div class="col-lg-6">
                        <!-- menu item -->
                        <h1 style="font-size: x-large"><?php print_r($menu1[3]) ?></h1>
                        <div class="menu-item">
                            <h5><?php echo $portatad4[0] ?> </h5>
                            <div class="mi-meta">
                                <p><?php foreach($dolce5 as $value){
                                        echo $value . ", ";
                                    } ?>
                                </p>
                                <div class="menu-price">€<?php echo $prezzod4[0] ?></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

</section>
<!-- Menu section end -->


<!-- Featured sectoon -->
<section class="featured-section set-bg" data-setbg="MenuPage/img/featured-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-6 featured">
                <div class="section-title st-no-style text-left">
                    <i class="flaticon-022-tray"></i>
                    <h2 class="p-0">This Month’s Menu</h2>
                </div>
                <div class="menu-dark">
                    <div class="menu-item">
                        <div class="mi-meta">
                        <h5><?php echo $piuVenduto["NomeMenù"] ?></h5>

                            <div class="menu-price">€ <?php echo $piuVenduto["PrezzoMenu"] ?></div>
                        </div>
                    </div>
                </div>
                <p class="pb-3">Tempo verrà
                    in cui, con esultanza,
                    saluterai te stesso arrivato
                    alla tua porta, nel tuo proprio specchio,
                    e ognuno sorriderà al benvenuto dell'altro,

                    e dirà: Siedi qui. Mangia.
                    Amerai di nuovo lo straniero che era il tuo Io.
                    Offri vino. Offri pane. Rendi il cuore
                    a se stesso, allo straniero che ti ha amato

                    per tutta la vita, che hai ignorato
                    per un altro e che ti sa a memoria.
                    Dallo scaffale tira giù le lettere d'amore,

                    le fotografie, le note disperate,
                    sbuccia via dallo specchio la tua immagine.
                    Siediti. È festa: la tua vita è in tavola.</p>
            </div>
        </div>
    </div>
</section>
<!-- Featured sectoon end -->


<!--====== Javascripts & Jquery ======-->
<script src="MenuPage/js/jquery-3.2.1.min.js"></script>
<script src="MenuPage/js/bootstrap.min.js"></script>
<script src="MenuPage/js/owl.carousel.min.js"></script>
<script src="MenuPage/js/circle-progress.min.js"></script>
<script src="MenuPage/js/main.js"></script>


</body>
</html>