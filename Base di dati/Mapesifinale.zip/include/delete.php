<?php
include_once '../include/connection.php';

    $cf = $_GET['id'];

    $query = "delete from personale where CF = '$cf'";

    $data = mysqli_query($conn, $query);
     if ($data)
     {
         echo "<font color = 'green' > ELIMINATO";
     }else
     {
         echo "<font color = 'red' > NON E' STATO ELIMINATO";
     }

header('location:/Mapesi/Filiali/filiale74014.php');
?>
