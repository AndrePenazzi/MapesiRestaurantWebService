<?php
	include_once 'connection.php';
?>

<?php
$error='';//variable to store error message;
if(isset($_POST['submit'])){
	if(empty($_POST['user']) || empty($_POST['pass'])){
		$error='username or password invalid';
	}
	else{
		//define $user and $pass
		$type = $_POST['type'];
		$user = $_POST['user'];
		$pass = $_POST['pass'];
		//establishing connection with query
		$query = mysqli_query($conn, "select * from personaldata where user='$user' and pass='$pass'");
		
		
		while($rows= mysqli_fetch_array($query)){

		if($rows['user']==$user && $rows['pass']==$pass){
			header("Location: ./Queries.php");//redirecting to next page
		}
		else{
			$error = "username or password is inavlid";
		}
		}		
	}
}
?>