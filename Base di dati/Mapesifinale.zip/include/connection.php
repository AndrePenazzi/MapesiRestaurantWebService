<?php
	
$dbServerName = "localhost";
$dbUsername = "root";
$dbPassword = "mysql";
$dbName = "mapesirestaurant";

$conn = mysqli_connect($dbServerName, $dbUsername, $dbPassword, $dbName );
?>