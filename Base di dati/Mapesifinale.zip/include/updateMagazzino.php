
<?php

include 'connection.php';
include '../css/AggiungereCSS.php';

if (isset($_POST['submit'])){
    $nomeIng = $_POST['NomeIngrediente'];
    $tipo = $_POST['Tipo'];
    $quantita = $_POST['Quantità'];

    $sql = "update magazzino set NomeIngrediente='$nomeIng', Tipo='$tipo', Quantità='$quantita' WHERE NomeIngrediente='$nomeIng'";
    $query = mysqli_query($conn, $sql);

    header('location:/Mapesi/magazzino.php');
}

?>

<div class="aggiungere">
<form action="" method="POST">
    <div class="form-row">

        <h1>Inserire informazione da aggiornare</h1>
        <!--<input type="text" name="idmenu" placeholder="idmenu">
        <input type="text" name="nomemenu" placeholder="nomemenu">
        <input type="text" name="prezzomenu" placeholder="prezzomenu">-->


        <input type="text" name="NomeIngrediente" placeholder="Nome Ingrediente" value="<?php echo $_GET['nI']; ?>">

        <input type="text" name="Tipo" placeholder="Tipo" value="<?php echo $_GET['tipo']; ?>">

        <input type="text" name="Quantità" placeholder="Quantita" value="<?php echo $_GET['Quantita'];?>">





        <button type="submit" name = "submit" class="btn btn-primary">Aggiorna</button>
    </div>
</form>

