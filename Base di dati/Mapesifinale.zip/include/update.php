
<?php

include 'connection.php';
include '../css/AggiungereCSS.php';

if (isset($_POST['submit'])){
    $cf = $_POST['cf'];
    $CodiceDipendente = $_POST['CodiceDipendente'];
    $Nome = $_POST['Nome'];
    $Cognome = $_POST['Cognome'];
    $Ruolo = $_POST['Ruolo'];
    $Citta = $_POST['Citta'];
    $GiornoRiposo = $_POST['GiornoRiposo'];
    $PagaOraria = $_POST['PagaOraria'];
    $Telefono = $_POST['Telefono'];
    $CodiceFiliale = $_POST['CodiceFiliale'];
    $DataAssunzione = $_POST['DataAssunzione'];
    $OreLavorate = $_POST['OreLavorate'];

    $sql = "update personale set CF='$cf', CodiceDipendente='$CodiceDipendente', Nome='$Nome', Cognome='$Cognome', Ruolo='$Ruolo', Citta='$Citta', GiornoRiposo='$GiornoRiposo', PagaOraria='$PagaOraria',
            Telefono='$Telefono' WHERE CF='$cf'";
    $query = mysqli_query($conn, $sql);

    if($query){
        $sql2 = "update lavora set CF='$cf', CodiceDip='$CodiceDipendente', CodiceFiliale='$CodiceFiliale', DataAssunzione='$DataAssunzione', OreLavorate='$OreLavorate' WHERE CF='$cf'";
        mysqli_query($conn, $sql2);
    }

    header('location:/Mapesi/Filiali/filiale74014.php');
}

?>

<div class="aggiungere">
<form action="" method="POST">
    <div class="form-row">

        <h1>Inserire informazione da aggiornare</h1>
        <!--<input type="text" name="idmenu" placeholder="idmenu">
        <input type="text" name="nomemenu" placeholder="nomemenu">
        <input type="text" name="prezzomenu" placeholder="prezzomenu">-->


        <input type="text" name="cf" placeholder="CF" value="<?php echo $_GET['cf']; ?>">

        <input type="text" name="CodiceDipendente" placeholder="CodiceDipendente" value="<?php echo $_GET['cd']; ?>">

        <input type="text" name="Nome" placeholder="Nome" value="<?php echo $_GET['name'];?>">

        <input type="text" name="Cognome" placeholder="Cognome" value="<?php echo $_GET['cog'];?>">

        <input type="text" name="Ruolo" placeholder="Ruolo" value="<?php echo $_GET['r']; ?>">

        <input type="text" name="Citta" placeholder="Citta" value="<?php echo $_GET['c']; ?>">

        <input type="text" name="GiornoRiposo" placeholder="GiornoRiposo" value="<?php echo $_GET['gr']; ?>">

        <input type="text" name="PagaOraria" placeholder="PagaOraria" value="<?php echo $_GET['p']; ?>">

        <input type="text" name="Telefono" placeholder="Telefono" value="<?php echo $_GET['tel']; ?>">

        <input type="text" name="CodiceFiliale" placeholder="CodiceFiliale" value="<?php echo $_GET['cfi']; ?>">

        <input type="text" name="DataAssunzione" placeholder="DataAssunzione" value="<?php echo $_GET['da']; ?>">

        <input type="text" name="OreLavorate" placeholder="OreLavorate" value="<?php echo $_GET['ol']; ?>">



        <button type="submit" name = "submit" class="btn btn-primary">Aggiorna</button>
    </div>
</form>

