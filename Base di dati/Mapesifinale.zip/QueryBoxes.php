<?php

$sql = "select * from personale as p
						INNER JOIN lavora as l
						ON p.CF = l.CF
						order by Nome";

$result = mysqli_query($conn, $sql);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $res += $row['OreLavorate'] * $row['PagaOraria'] . "<br>";
    }

}


$sql1 = "select * from rifornisce";

$result1 = mysqli_query($conn, $sql1);
$resultCheck1 = mysqli_num_rows($result1);

if ($resultCheck1 > 0) {
    while ($row1 = mysqli_fetch_assoc($result1)) {
        //$res1 += $row1['QuantitàRifornita'] * $row1['PrezzoTotale'] . "<br>";
        $res1 += $row1['PrezzoTotale'] . "<br>";
    }
}
?>

<!-- query guadagnoTotale -->
<?php
//$guadagno = "SELECT Menu, NomeMenù, PrezzoMenu, sum(QuantitàMenu)  FROM `ordine` as o join menu as m on o.Menu = m.IDMenu GROUP BY Menu";
$guadagno = "SELECT Menu, NomeMenù, PrezzoMenu, sum(QuantitàMenu)  FROM `ordine` as o join menu as m on o.Menu = m.IDMenu GROUP BY Menu";

$guadagnoQuery = mysqli_query($conn, $guadagno);
$guad = mysqli_num_rows($guadagnoQuery);

if ($guad > 0) {
    while ($row2 = mysqli_fetch_assoc($guadagnoQuery)) {
        $guadagoTotale += $row2['PrezzoMenu'] * $row2['sum(QuantitàMenu)'] . "<br>";
    }
}
?>


<div class="row">
    <!--upper left-->

    <div class="col-sm-6">
        <div class="card">
            <div class="p-3 mb-2 bg-success text-white">
                <div class="card-body">
                    <div class="text-center" style="font-size:200%;">
                        <h5 class="font-weight-bold">Costo Mensile Personale</h5>

                        <?php
                        echo $res . " €";
                        ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--upper right-->
    <div class="col-sm-6">
        <div class="card">
            <div class="p-3 mb-2 bg-danger text-white">
                <div class="card-body">
                    <div class="text-center" style="font-size:200%;">
                        <h5 class="font-weight-bold">Valore Fornitura</h5>

                        <?php
                        echo $res1 . " €";
                        ?>

                        <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--lower left-->
    <div class="col-sm-6">
        <div class="card">
            <div class="p-3 mb-2 bg-warning text-dark">
                <div class="card-body">
                    <div class="text-center" style="font-size:200%;">
                        <h5 class="font-weight-bold">Costo Totale Mensile</h5>

                        <?php
                        echo $res + $res1 . " €";
                        ?>

                        <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--lower right-->
    <div class="col-sm-6">
        <div class="card">
            <div class="p-3 mb-2 bg-info text-white">
                <div class="card-body">
                    <div class="text-center" style="font-size:200%;">
                        <h5 class="font-weight-bold">Guadagno Totale</h5>
                        <?php
                        echo $guadagoTotale . " €";
                        ?>
                        <!-- <a href="#" class="btn btn-primary">Go somewhere</a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>