<?php
include_once 'include/connection.php';
?>

<head>
    <title>Mapesi - Restaurant </title>
    <meta charset="UTF-8">
    <meta name="description" content="Pulse Restaurant HTML Template">
    <meta name="keywords" content="pulse, restaurant, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link href="MenuPage/img/favicon.ico" rel="shortcut icon"/>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="MenuPage/css1/bootstrap.min.css"/>
    <link rel="stylesheet" href="MenuPage/css1/font-awesome.min.css"/>
    <link rel="stylesheet" href="MenuPage/css1/flaticon.css"/>
    <link rel="stylesheet" href="MenuPage/css1/owl.carousel.css"/>
    <link rel="stylesheet" href="MenuPage/css1/style.css"/>
    <link rel="stylesheet" href="MenuPage/css1/animate.css"/>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal">Mapesi Group of Restaurants</h5>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="./Filiali/Fornitori.php"><button type="submit" name = "fornitori" class="btn btn-outline-success">Fornitori</button></a>
        <a class="p-2 text-dark" href="index.php"><button type="submit" name = "fornitori" class="btn btn-outline-success">Home</button></a>
    </nav>
</div>

<body>

<!-- Page Preloder -->
<div id="preloder">
    <div class="loader"></div>
</div>

<section class="mp-menu-section spad">
    <div class="container">
        <ul class="mp-menu-tab-nav nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1"
                   aria-selected="false">
                    <i class="flaticon-005-coffee-1"></i>
                    <div class="mpm-text">
                        <h5>ORDINI</h5>

                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2"
                   aria-selected="false">
                    <i class="flaticon-013-salad"></i>
                    <div class="mpm-text">
                        <h5>MAGAZZINO</h5>

                    </div>
                </a>
            </li>
        </ul>

        <?php

        $ds = "SELECT * FROM `ordine` as o join menu as m on o.Menu = m.IDMenu ORDER BY o.data asc ";


        $result = mysqli_query($conn, $ds);
        ?>

        <?php

        $sql = "SELECT * FROM magazzino ";


        $result1 = mysqli_query($conn, $sql);
        ?>



        <div class="tab-content menu-tab-content">

            <!-- single tab content -->
            <!--Tab ORDINE-->
            <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
                <div class="row menu-dark">

                    <table class="table table-bordered">
                        <tr>
                            <th>N.ORDINE</th>
                            <th>DATA</th>
                            <th>MENU</th>
                            <th>QuantitàMenu</th>




                        </tr>
                        <?php while($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                    <td>".$row['N.Ordine']."</td>
                                    <td>".$row['data']."</td>
                                    <td>".$row['NomeMenù']."</td>
                                    <td>".$row['QuantitàMenu']."</td>
                                   </tr>";
                        } ?>
                    </table>


                </div>
            </div>


            <!-- single tab content -->
            <!--Tab MAGAZZINO-->
            <div class="tab-pane fade " id="tab-2" role="tabpanel" aria-labelledby="tab-2">
                <div class="row menu-dark">

                    <table class="table table-bordered">
                        <tr>
                            <th>Nome Ingrediente</th>
                            <th>Tipo</th>
                            <th>Quantità</th>
                            <th colspan="2" >Operazioni</th>



                        </tr>
                        <?php while($row1 = mysqli_fetch_assoc($result1)) {
                            echo "<tr>
                                    <td>".$row1['NomeIngrediente']."</td>
                                    <td>".$row1['Tipo']."</td>
                                    <td>".$row1['Quantità']."</td>
                                                                    
                                    <td><a href='include/updateMagazzino.php? nI=$row1[NomeIngrediente]& tipo=$row1[Tipo]& Quantita=$row1[Quantità]'>
                                   <button class='btn-dark btn'> Aggiorna</button></a></td>
                                    
                                   </tr>";
                        } ?>
                    </table>

                </div>
            </div>

        </div>

</section>

</body>

<script src="MenuPage/js/jquery-3.2.1.min.js"></script>
<script src="MenuPage/js/bootstrap.min.js"></script>
<script src="MenuPage/js/owl.carousel.min.js"></script>
<script src="MenuPage/js/circle-progress.min.js"></script>
<script src="MenuPage/js/main.js"></script>









