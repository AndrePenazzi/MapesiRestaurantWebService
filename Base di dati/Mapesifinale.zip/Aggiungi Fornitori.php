<?php

include 'include/connection.php';
include 'css/AggiungereCSS.php'
?>
<?php

$Piva = $_POST['PIVA'];
$Nome = $_POST['Nome'];
$Email = $_POST['Email'];
$Tipologia = $_POST['Tipologia'];
$Citta = $_POST['Città'];

echo $sql = "insert into fornitori (PIVA,Nome,Email,Tipologia,Città) values ('$Piva', '$Nome', '$Email', '$Tipologia', '$Citta')";
//$sql = "insert into fornitori set P.IVA='$Piva'Nome='$Nome'Email='$Email'Tipologia='$Tipologia'Città='$Citta'";
mysqli_query($conn, $sql) or die("Non è andato a buon fine");
header("location:/Mapesi/Filiali/Fornitori.php");
?>

