<?php
include_once 'include/connection.php';
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Mapesi - Restaurant</title>
	<meta charset="UTF-8">
	<meta name="description" content="Pulse Restaurant HTML Template">
	<meta name="keywords" content="pulse, restaurant, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="MenuPage/img/favicon.ico" rel="shortcut icon"/>

	<!-- Stylesheets -->
	<link rel="stylesheet" href="MenuPage/css1/bootstrap.min.css"/>
	<link rel="stylesheet" href="MenuPage/css1/font-awesome.min.css"/>
	<link rel="stylesheet" href="MenuPage/css1/flaticon.css"/>
	<link rel="stylesheet" href="MenuPage/css1/owl.carousel.css"/>
	<link rel="stylesheet" href="MenuPage/css1/style.css"/>
	<link rel="stylesheet" href="MenuPage/css1/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>
	
	<!-- Header section -->
	<header class="header-section">
		<div class="header-warp">
			<div class="site-logo">
				<h2>MAPESI<span>.</span></h2>
			</div>
			<!-- responsive -->
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<!-- menu -->
			<ul class="main-menu">
				<li><a href="index.php" class="active">Home</a></li>
				<li><a href="MenuPage.php">Menu</a></li>
				<li><a href="contact.php">Contatti</a></li>
                <li><a href="Login.php">Personale</a></li>
			</ul>
			<div class="site-logo">
				<h2><span>Group of Restaurants</span></h2>
			</div>
		</div>
	</header>
	<!-- Header section end -->


	<!-- Hero section -->
	<section class="hero-section">
		<div class="hero-slider owl-carousel">
			<div class="hs-item set-bg" data-setbg="MenuPage/img/slider/slider-1.jpg">
				<div class="hs-content">
					<div class="hsc-warp">
						<h2>Food and more<span>.</span></h2>
						<p>By Chef Flavio Bergel</p>
					</div>
				</div>
			</div>
			<div class="hs-item set-bg" data-setbg="MenuPage/img/slider/slider-2.jpg">
				<div class="hs-content">
					<div class="hsc-warp">
						<h2>Special Dish<span>.</span></h2>
						<p>By Chef Flavio Bergel</p>
					</div>
				</div>
			</div>
			<div class="hs-item set-bg" data-setbg="MenuPage/img/slider/slider-3.jpg">
				<div class="hs-content">
					<div class="hsc-warp">
						<h2>Healthy Food<span>.</span></h2>
						<p>By Chef Flavio Bergel</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Hero section end -->



	<!-- Intro section -->
	<section class="inter-section spad">
		<div class="container">
			<div class="section-title">
				<i class="flaticon-019-rib"></i>
				<h2>Benvenuti</h2>
			</div>
			<div>
				<div>
				
					<p>Noi interpretiamo la QUALITA'
come una parola che deve andare pari-passo con il significato di ENTUSIASMO ed INNOVAZIONE;
termini indispensabili che hanno l'obbiettivo  di metterci alla ricerca, sia della materia prima,  nel rispetto della nostra tradizione culinaria, sia delle nuove tecnologie al fine di valorizzare il prodotto finito.
Acquistiamo la maggiore parte dei prodotti utilizzati nelle nostre cucine, da fornitori locali per meglio valorizzare il gusto e i sapori locali, spaziando dal pesce ai salumi, dai latticini alle bevande.</p>
				</div>
				</div>
			<div class="text-center">
				<img src="MenuPage/img/sign.png" alt="">
			</div>
		</div>
	</section>
	<!-- Intro section end -->



	<!-- Testimonials section -->
	<!--<section class="testimonials-section spad pb-0 set-bg" data-setbg="MenuPage/img/review-bg.jpg">
		<div class="container">
			<div class="section-title text-white">
				<i class="flaticon-020-ice-cream"></i>
				<h2>Testimonials</h2>
			</div>
			<div class="testimonials-slider owl-carousel">
				<div class="ts-item text-white">
					<div class="quota">“</div>
					<p>Integer sed facilisis eros. In iaculis rhoncus velit in malesuada. In hac habitasse platea dictumst. Fusce erat ex, consectetur sit amet ornare suscipit, porta et erat. Donec nec nisi in nibh commodo laoreet. Mauris dapibus justo ut feugiat malesuada. Fusce ultricies ante tortor, non vestibulum est feu-giat ut. </p>
					<h6><span>Ted Chapman</span>, Client</h6>
				</div>
				<div class="ts-item text-white">
					<div class="quota">“</div>
					<p>Integer sed facilisis eros. In iaculis rhoncus velit in malesuada. In hac habitasse platea dictumst. Fusce erat ex, consectetur sit amet ornare suscipit, porta et erat. Donec nec nisi in nibh commodo laoreet. Mauris dapibus justo ut feugiat malesuada. Fusce ultricies ante tortor, non vestibulum est feu-giat ut. </p>
					<h6><span>Ted Chapman</span>, Client</h6>
				</div>
				<div class="ts-item text-white">
					<div class="quota">“</div>
					<p>Integer sed facilisis eros. In iaculis rhoncus velit in malesuada. In hac habitasse platea dictumst. Fusce erat ex, consectetur sit amet ornare suscipit, porta et erat. Donec nec nisi in nibh commodo laoreet. Mauris dapibus justo ut feugiat malesuada. Fusce ultricies ante tortor, non vestibulum est feu-giat ut. </p>
					<h6><span>Ted Chapman</span>, Client</h6>
				</div>
			</div>
		</div>
	</section>-->
	<!-- Testimonials section end -->

	<?php
      $sql = "SELECT *from ristoranti;";
      $result = mysqli_query($conn, $sql);
      $resultCheck = mysqli_num_rows($result);

      if($resultCheck > 0){
	while($row = mysqli_fetch_assoc($result)){
	    $branch[] = $row['Città'];
	    $addr[] = $row['Indirizzo'];

	}
	}
	?>


	<!-- Services section -->
	<section class="services-section spad">
		<div class="container">
			<div class="section-title">
				<i class="flaticon-022-tray"></i>
				<h2>La Nostra Catena Di Ristoranti</h2>
			</div>
			<div class="row services">
				<div class="col-lg-3 col-md-6 service-item">
					<h3><?php print_r($branch[0])?></h3>
					<p><?php print_r($addr[0])?></p>
				</div>
				<div class="col-lg-3 col-md-6 service-item">

					<h3><?php print_r($branch[1])?></h3>
					<p><?php print_r($addr[1])?></p>
				</div>
				<div class="col-lg-3 col-md-6 service-item">

					<h3><?php print_r($branch[2])?></h3>
					<p><?php print_r($addr[2])?></p>
				</div>
				<div class="col-lg-3 col-md-6 service-item">

					<h3><?php print_r($branch[3])?></h3>
					<p><?php print_r($addr[3])?></p>
				</div>
			</div>
		</div>
	</section>
	<!-- Services section end -->



	<!--====== Javascripts & Jquery ======-->
	<script src="MenuPage/js/jquery-3.2.1.min.js"></script>
	<script src="MenuPage/js/bootstrap.min.js"></script>
	<script src="MenuPage/js/owl.carousel.min.js"></script>
	<script src="MenuPage/js/circle-progress.min.js"></script>
	<script src="MenuPage/js/main.js"></script>




    </body>
</html>